# TSDemo

A plugin that displays a simple donation form on a WordPress site, using Stripe for payment processing.

## Getting Started

Install the plugin on your WordPress site via the admin panel and place the requisite keywords on a page or post.

### Prerequisites

WordPress

### Installing

If you're unfamiliar with the process of installing a custom plugin, please see the [WordPress Codex](https://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation) entry for assistance.

## Running the tests

Gotta write these.

```
For example
```

## Versioning

Pending review and client approval, this project is an alpha release.

## Authors

* ** Brendan Adkins** - https://github.com/BrendanAdkins

## License

This project is not currently licensed for reuse, but will be once the code is stable.
